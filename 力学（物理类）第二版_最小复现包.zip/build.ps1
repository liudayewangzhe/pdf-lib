﻿# 需要 TeX Live 2024 (xelatex)
Set-Location $PSScriptRoot
for ($i = 1; $i -le 3; $i++) {
    Write-Host "xelatex pass $i"
    & xelatex -interaction=nonstopmode -halt-on-error main.tex
    if ($LASTEXITCODE -ne 0) { Write-Error "pass $i failed"; exit 1 }
}
Write-Host "done: main.pdf"
