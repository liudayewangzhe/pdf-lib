# 力学（物理类）第二版 —— 最小重现包

## 内容

| 路径 | 说明 |
|---|---|
| `力学（物理类）第二版.pdf` | 成书 PDF（962 页，3.7 MB） |
| `原书_力学物理类第二版_舒幼生.pdf` | 原始扫描件（518 页，重建依据） |
| `src/main.tex` | 全书 LaTeX 主文件（引擎生成，正文 + 公式 + 图全部内联） |
| `src/elegantbook.cls` | 排版文档类（本地副本，改动过版面参数） |
| `src/nativeforge.sty` | 项目样式宏包（TikZ 矢量图样式、数学宏等） |
| `src/assets/` | 插图位图（三维图/器件图按源页 300 dpi 精确裁切） |
| `build.ps1` | 一键编译脚本（xelatex 三遍） |

## 编译方法

1. 安装 **TeX Live 2024（full）**，确保 `xelatex` 在 PATH 中；
2. 安装 Windows 中文字体：**宋体 SimSun、黑体 SimHei、楷体 KaiTi、微软雅黑 Microsoft YaHei**
   （Windows 自带；非 Windows 请改用 ctex 的 fandol 字体集，见下）；
3. 进入 `src/` 目录执行：

```powershell
xelatex -interaction=nonstopmode main.tex
xelatex -interaction=nonstopmode main.tex
xelatex -interaction=nonstopmode main.tex
```

或直接双击 `build.ps1`。

编译结果：**962 页**，与包内 PDF 页数一致；正文文本与包内 PDF 完全一致（已用独立复编验证）。

## 依赖说明

- **LaTeX 宏包**：全部来自 TeX Live 2024 标准发行版（elegantbook 依赖的 ctex、xeCJK、
  fontspec、unicode-math、tikz/pgf、booktabs、tcolorbox 等均为标准包），无需额外安装。
- **数学字体**：TeXGyreTermesX、NewCMMath、NewCMMono、STIX Two Math（均在 TeX Live 内）。
- **中文字体**：宋体/黑体/楷体/微软雅黑为 Windows 系统字体。若在 macOS/Linux 上复编，
  把 `src/main.tex` 第一行改为
  `\documentclass[lang=cn,11pt,math=cm,chinesefont=nofont]{elegantbook}`
  并在其后加一行 `\setCJKmainfont{FandolSong-Regular.otf}`，用 TeX Live 自带的 Fandol 字体集
  （字形会与原版略有差异，页数可能变化）。
- **图片**：均为 PNG 位图，无需额外图形包。

## 版本

- 源页覆盖：500 / 500 页，语义分块 114 / 114
- 版式：176×250 mm，正文宽 138 mm，11 pt，行距 1.38
- 校验：`nf build` / `nf qa` 通过；独立复编（另建工程重新编译）页数与全文文本哈希一致
